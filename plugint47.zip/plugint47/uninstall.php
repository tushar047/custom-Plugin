<?php
    if(!defined('WP_UNINSTALL_PLUGIN')){
        die;
    }
    
    $page_id = get_option( 'account');
    wp_delete_post( $page_id );